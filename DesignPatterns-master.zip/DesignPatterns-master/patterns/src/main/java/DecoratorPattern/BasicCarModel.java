package DecoratorPattern;

public class BasicCarModel implements CarModel{
	public void model() {
		// TODO Auto-generated method stub
		System.out.println("A basic car Model");
	}

}
